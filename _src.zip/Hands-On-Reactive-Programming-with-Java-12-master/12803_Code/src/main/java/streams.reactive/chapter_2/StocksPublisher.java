package streams.reactive.chapter_2;

import java.util.concurrent.SubmissionPublisher;

public class StocksPublisher extends SubmissionPublisher<StockData> {


}
